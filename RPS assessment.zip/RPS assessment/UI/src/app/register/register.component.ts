import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  url:string= "http://localhost:8080/UserRegistrationDetails";
  result:any;
  a:any;
  duplicateEmail: any;


  userForm = new FormGroup({
    fullName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    companyName: new FormControl('', [Validators.required]),
    jobRole: new FormControl('', [Validators.required]),
    totalUserOrg: new FormControl('', [Validators.required]),
    countryRegion: new FormControl('', [Validators.required])
  })
  constructor(private http:HttpClient,private router: Router) { }

  ngOnInit(): void {
  }

  submit():void{
      this.http.post(this.url,this.userForm.value).subscribe(data=>{
            this.result = data;
            this.a = Object.values(this.result);
   
            localStorage.setItem('userId',this.a[0]);
            localStorage.setItem('fullName',this.a[1]);
            localStorage.setItem('email',this.a[2]);
          
            this.router.navigate(['device']);

      },error=>{
            this.duplicateEmail = "*Email is already Registered";
            this.router.navigate(['register']);

      });
  
  }
  

}
