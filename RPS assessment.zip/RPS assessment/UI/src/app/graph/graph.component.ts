import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { SurveyService } from './../services/survey.service';

import { Component, ViewChild, ElementRef ,OnInit} from '@angular/core';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';

import {  } from "@angular/core";
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexXAxis,
  ApexPlotOptions,
  ApexStroke,
  ApexTitleSubtitle
} from "ng-apexcharts";


export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
  title: ApexTitleSubtitle;
};

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
})
export class GraphComponent implements OnInit {

  userForm: FormGroup;

  a:any;
  actualFinalRatingOne: any;
  idealFinalRatingOne: any;
  actualFinalRatingTwo:any;
  idealFinalRatingTwo:any;
  actualFinalRatingThree:any;
  idealFinalRatingThree:any;
  actualFinalRatingFour:any;
  idealFinalRatingFour:any;
  
  actualRatingSubcategoryOne:any;
  actualRatingSubcategoryTwo:any;
  actualRatingSubcategoryThree:any;
  actualRatingSubcategoryFour:any;
  actualRatingSubcategoryFive:any;
  idealRatingSubcategoryOne:any;
  idealRatingSubcategoryTwo:any;
  idealRatingSubcategoryThree:any;
  idealRatingSubcategoryFour:any;
  idealRatingSubcategoryFive:any;

  actualRatingSubcategorySix:any;
  actualRatingSubcategorySeven:any;
  actualRatingSubcategoryEight:any;

  idealRatingSubcategorySix:any;
  idealRatingSubcategorySeven:any;
  idealRatingSubcategoryEight:any;

  actualRatingSubcategoryNine:any;
  actualRatingSubcategoryTen:any;
  actualRatingSubcategoryEleven:any;
  actualRatingSubcategoryTwelve:any;

  idealRatingSubcategoryNine:any;
  idealRatingSubcategoryTen:any;
  idealRatingSubcategoryEleven:any;
  idealRatingSubcategoryTwelve:any;

  actualRatingSubcategoryThirteen:any;
  actualRatingSubcategoryFourteen:any;
  actualRatingSubcategoryFifteen:any;
  idealRatingSubcategoryThirteen:any;
  idealRatingSubcategoryFourteen:any;
  idealRatingSubcategoryFifteen:any;

  blobCopy:Blob;
  title = 'angular-tour-of-fileupload';
  formData: any = {
    email:null,
    Outcome: null,
    blobDetailsIng: ''
  }




    result1:any;
    result2:any;
    result3:any;
    result4:any;

    url:string= "http://localhost:8080/QuestionDetails/Collaboration";

    url1:string="http://localhost:8080/UserFeedbackDetails/CategoryOne/";
    url2:string="http://localhost:8080/UserFeedbackDetails/CategoryTwo/";
    url3:string="http://localhost:8080/UserFeedbackDetails/CategoryThree/";
    url4:string="http://localhost:8080/UserFeedbackDetails/CategoryFour/";
    

    
 

    
  @ViewChild("chart") chart: ChartComponent;
  @ViewChild('inputFile', {static:true}) inputFile: ElementRef;
  @ViewChild('content') content: ElementRef;
  public chartOptions1: any;
  public chartOptions2: any;
  public chartOptions3: any;
  public chartOptions4: any;
  public chartOptions5: any;
  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder, public surveyService :SurveyService ) {}
  
  
  
 
  
  
  ngAfterContentInit(): void {
    //Called after ngOnInit when the component's or directive's content has been initialized.
    //Add 'implements AfterContentInit' to the class.

    setTimeout(() => {
         
  
      let email = localStorage.getItem('email');
      let fullName = localStorage.getItem('fullName');
     console.log(fullName);
     console.log(email);
      const formData=new FormData();

   formData.append("email", email); 
   formData.append("fullName", fullName);
 
 
    html2canvas(document.body).then( (canvas) => {
     
      canvas.toBlob( (blob2) => {
 
        var imgWidth = 208;
        var pageHeight = 200;
        var imgHeight = canvas.height * imgWidth / canvas.width;
        var heightLeft = imgHeight;

         
        const contentDataURL = canvas.toDataURL('image/png',0.3)
     
        var pdf = new jspdf({compress: true});
        var position = 0;
        pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
        pdf.save('RPSAssessment.pdf');


     

        let pdffile = pdf.output('blob');
        console.log(pdffile);
        this.formData.blobDetailsIng = new File([pdffile],'RPSAssessment.pdf',{ 'type' :'application/pdf'});
          console.log(this.formData.blobDetailsIng);
          console.log(this.formData.blobDetailsIng.name);
          formData.append("blobDetailsIng", this.formData.blobDetailsIng, this.formData.blobDetailsIng.name);
         
        console.log(email);
        console.log(fullName);


        this.surveyService.uploadFile(formData).subscribe((response) => {
          console.log(response);
          console.log("Success")
        });

        
         },'application/pdf');

         
           console.log(fullName);
           console.log("Hello");
 

        });
      }, 5000);
  }
    ngOnInit() {
      this.a = localStorage.getItem('userId');

      //Device

      this.http.get(this.url1+this.a).subscribe(data=>{
        this.result1 = data; 
       
        this.actualFinalRatingOne = this.result1[0][0]+this.result1[1][0]+this.result1[2][0]+this.result1[3][0]+this.result1[4][0];
        localStorage.setItem('actualFinalRatingOne',this.actualFinalRatingOne.toFixed(3));
        this.idealFinalRatingOne = this.result1[0][1]+this.result1[1][1]+this.result1[2][1]+this.result1[3][1]+this.result1[4][1];

        localStorage.setItem('idealFinalRatingOne',this.idealFinalRatingOne.toFixed(3));


        
        this.actualRatingSubcategoryOne = this.result1[0][0].toFixed(3);
        this.actualRatingSubcategoryTwo = this.result1[1][0].toFixed(3);
        this.actualRatingSubcategoryThree = this.result1[2][0].toFixed(3);
        this.actualRatingSubcategoryFour = this.result1[3][0].toFixed(3);
        this.actualRatingSubcategoryFive = this.result1[4][0].toFixed(3);

        this.idealRatingSubcategoryOne = this.result1[0][1].toFixed(3);
        this.idealRatingSubcategoryTwo = this.result1[1][1].toFixed(3);
        this.idealRatingSubcategoryThree = this.result1[2][1].toFixed(3);
        this.idealRatingSubcategoryFour = this.result1[3][1].toFixed(3);
        this.idealRatingSubcategoryFive = this.result1[4][1].toFixed(3);
      
        
        this.chartOptions1 = {
          series: [
            {
              name: "Actual Rating",
         
              data: [this.actualRatingSubcategoryFive, this.actualRatingSubcategoryFour, this.actualRatingSubcategoryThree, this.actualRatingSubcategoryTwo, this.actualRatingSubcategoryOne]
            },
            {
              name: "Ideal Rating",
             
              data: [this.idealRatingSubcategoryFive,this.idealRatingSubcategoryFour, this.idealRatingSubcategoryThree, this.idealRatingSubcategoryTwo, this.idealRatingSubcategoryOne]
            }
          ]
          ,
      
          chart: {
            type: "bar",
            height: 250
          },
          title: {
            text: "Device Rating",
            offsetX: 180
          },
          plotOptions: {
            bar: {
              horizontal: true,
              dataLabels: {
                position: "top"
              }
            }
          },
          dataLabels: {
            enabled: false,
            offsetX: -6,
            style: {
              fontSize: "0px",
              colors: ["#fff"]
            }
          },
          stroke: {
            show: true,
            width: 1,
            colors: ["#fff"]
          },
          xaxis: {
            categories: ["COE","VDI","Remote working Enablement","BYOD" ,"Device Coverage"]
          }
        };
      
      });
      
      
      //Secure Connectivity
      this.http.get(this.url4+this.a).subscribe(data=>{
      
        this.result4 = data; 
     
        this.actualFinalRatingFour = this.result4[0][0]+this.result4[1][0]+this.result4[2][0];
        localStorage.setItem('actualFinalRatingFour',this.actualFinalRatingFour.toFixed(3));
        this.idealFinalRatingFour = this.result4[0][1]+this.result4[1][1]+this.result4[2][1];
        localStorage.setItem('idealFinalRatingFour',this.idealFinalRatingFour.toFixed(3));
       
        this.actualRatingSubcategoryThirteen = this.result4[0][0].toFixed(3);
        this.actualRatingSubcategoryFourteen = this.result4[1][0].toFixed(3);
        this.actualRatingSubcategoryFifteen = this.result4[2][0].toFixed(3);

        this.idealRatingSubcategoryThirteen = this.result4[0][1].toFixed(3);
        this.idealRatingSubcategoryFourteen = this.result4[1][1].toFixed(3);
        this.idealRatingSubcategoryFifteen = this.result4[2][1].toFixed(3);

        this.chartOptions2 = {
          series: [
            {
              name: "Actual Rating",
              data: [this.actualRatingSubcategoryFifteen, this.actualRatingSubcategoryFourteen, this.actualRatingSubcategoryThirteen]
            },
            {
              name: "Ideal Rating",
    
              data: [this.idealRatingSubcategoryFifteen,  this.idealRatingSubcategoryFourteen, this.idealRatingSubcategoryThirteen]
            }
          ]
          ,
          title: {
            text: "Secure Connectivity Rating",
            offsetX: 80
          },
          chart: {
            type: "bar",
            height: 200
          },
          plotOptions: {
            bar: {
              horizontal: true,
              dataLabels: {
                position: "top"
              }
            }
          },
          dataLabels: {
            enabled: false,
            offsetX: -6,
            style: {
              fontSize: "0px",
              colors: ["#fff"]
            }
          },
          stroke: {
            show: true,
            width: 1,
            colors: ["#fff"]
          },
          xaxis: {
            categories: ["End-Point Security","Identity & Access Management","Corporate Network Access"]
          }
        };
      
      })


      //Collaboration

      this.http.get(this.url2+this.a).subscribe(data=>{
        this.result2 = data; 
        this.actualFinalRatingTwo = this.result2[0][0]+this.result2[1][0]+this.result2[2][0];
        localStorage.setItem('actualFinalRatingTwo',this.actualFinalRatingTwo.toFixed(3));
        this.idealFinalRatingTwo = this.result2[0][1]+this.result2[1][1]+this.result2[2][1];
        localStorage.setItem('idealFinalRatingTwo',this.idealFinalRatingTwo.toFixed(3));

        this.actualRatingSubcategorySix = this.result2[0][0].toFixed(3);
        this.actualRatingSubcategorySeven = this.result2[1][0].toFixed(3);
        this.actualRatingSubcategoryEight = this.result2[2][0].toFixed(3);

        this.idealRatingSubcategorySix = this.result2[0][1].toFixed(3);
        this.idealRatingSubcategorySeven = this.result2[1][1].toFixed(3);
        this.idealRatingSubcategoryEight = this.result2[2][1].toFixed(3);

        this.chartOptions3 = {
          series: [
            {
              name: "Actual Rating",
              data: [this.actualRatingSubcategoryEight, this.actualRatingSubcategorySeven, this.actualRatingSubcategorySix]           },
            {
              name: "Ideal Rating",
    
              data: [this.idealRatingSubcategoryEight, this.idealRatingSubcategorySeven, this.idealRatingSubcategorySix]
            }
          ],
          title: {
            text: "Collaboration Rating",
            offsetX: 100
          },
          chart: {
            type: "bar",
            height: 200
          },
          plotOptions: {
            bar: {
              horizontal: true,
              dataLabels: {
                position: "top"
              }
            }
          },
          dataLabels: {
            enabled: false,
            offsetX: -3,
            style: {
              fontSize: "0px",
              colors: ["#fff"]
            }
          },
          stroke: {
            show: true,
            width: 1,
            colors: ["#fff"]
          },
          xaxis: {
            categories: ["Evaluation and Monitoring","Enhancement Areas","Collaboration Tools Coverage"]
          }
        };
      
      });


      //Smart Services
      this.http.get(this.url3+this.a).subscribe(data=>{
        this.result3 = data; 
     
        this.actualFinalRatingThree = this.result3[0][0]+this.result3[1][0]+this.result3[2][0]+this.result3[3][0];
        localStorage.setItem('actualFinalRatingThree',this.actualFinalRatingThree.toFixed(3));
        this.idealFinalRatingThree = this.result3[0][1]+this.result3[1][1]+this.result3[2][1]+this.result3[3][1];
        localStorage.setItem('idealFinalRatingThree',this.idealFinalRatingThree.toFixed(3));

        this.actualRatingSubcategoryNine = this.result3[0][0].toFixed(3);
        this.actualRatingSubcategoryTen = this.result3[1][0].toFixed(3);
        this.actualRatingSubcategoryEleven = this.result3[2][0].toFixed(3);
        this.actualRatingSubcategoryTwelve = this.result3[3][0].toFixed(3);

        this.idealRatingSubcategoryNine = this.result3[0][1].toFixed(3);
        this.idealRatingSubcategoryTen = this.result3[1][1].toFixed(3);
        this.idealRatingSubcategoryEleven = this.result3[2][1].toFixed(3);
        this.idealRatingSubcategoryTwelve = this.result3[3][1].toFixed(3);

        this.chartOptions4 = {
          series: [
            {
              name: "Actual Rating",
              data: [this.actualRatingSubcategoryTwelve, this.actualRatingSubcategoryEleven, this.actualRatingSubcategoryTen, this.actualRatingSubcategoryNine]
            },
            {
              name: "Ideal Rating",
    
              data: [this.idealRatingSubcategoryTwelve, this.idealRatingSubcategoryEleven,this.idealRatingSubcategoryTen, this.idealRatingSubcategoryNine]
            }
          ],
          
          title: {
            text: "Smart Services Rating",
            offsetX: 170
          },
          chart: {
            type: "bar",
            height: 200
          },
          plotOptions: {
            bar: {
              horizontal: true,
              dataLabels: {
                position: "top"
              }
            }
          },
          dataLabels: {
            enabled: false,
            offsetX: -6,
            style: {
              fontSize: "0px",
              colors: ["#fff"]
            }
          },
          stroke: {
            show: false,
            width: 1,
            colors: ["#fff"]
          },
          xaxis: {
            categories: ["User Experience","Persona Based Services","Support","Adoption"]
          }
        };
      
      });

this.vectorfourGraph();



   


    }

    public vectorfourGraph(){
      
let z1 = localStorage.getItem('actualFinalRatingOne');
let z2 = localStorage.getItem('actualFinalRatingTwo');
let z3 = localStorage.getItem('actualFinalRatingThree');
let z4 = localStorage.getItem('actualFinalRatingFour');

let z5 = localStorage.getItem('idealFinalRatingOne');
let z6 = localStorage.getItem('idealFinalRatingTwo');
let z7 = localStorage.getItem('idealFinalRatingThree');
let z8 = localStorage.getItem('idealFinalRatingFour');



      this.chartOptions5 = {
        series: [
          {
            name: "Actual Rating",
            data: [z3, z2, z4, z1]
          },
          {
            name: "Ideal Rating",
  
            data: [z7, z6, z8, z5]
          }
        ],
        
          title: {
            text: "Final Rating By 4 Vectors",
            offsetX: 300
          },
        chart: {
          type: "bar",
          height: 200
        },
        plotOptions: {
          bar: {
            horizontal: true,
            dataLabels: {
              position: "top"
            }
          }
        },
        dataLabels: {
          enabled: false,
          offsetX: -6,
          style: {
            fontSize: "0px",
            colors: ["#fff"]
          }
        },
        stroke: {
          show: true,
          width: 1,
          colors: ["#fff"]
        },
        xaxis: {
          categories: ["Smart Service","Collaboration","Secure Connectivity","Device"]
        }
      };

    }
}


   