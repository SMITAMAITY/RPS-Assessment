import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecureConnectivityComponent } from './secure-connectivity.component';

describe('SecureConnectivityComponent', () => {
  let component: SecureConnectivityComponent;
  let fixture: ComponentFixture<SecureConnectivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecureConnectivityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecureConnectivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
