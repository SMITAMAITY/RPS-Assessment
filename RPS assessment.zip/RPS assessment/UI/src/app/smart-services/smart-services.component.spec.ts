import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SmartServicesComponent } from './smart-services.component';

describe('SmartServicesComponent', () => {
  let component: SmartServicesComponent;
  let fixture: ComponentFixture<SmartServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SmartServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SmartServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
