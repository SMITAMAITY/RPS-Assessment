package com.lti.utils;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * @author 10653960
 *
 */
public class XFAUtils {

	private static final Logger LOGGER = LogManager.getLogger(XFAUtils.class);

	/**
	 * 
	 * @return todaysDate
	 */
	public static Date getTodaysDate() {

		Date todaysDate = new java.util.Date();
		LOGGER.debug("Todays Date: " + todaysDate);

		return todaysDate;
	}

	/**
	 * 
	 * @param dateToString
	 * @return
	 */
	public static String DateToString(Date dateToString) {

		return dateToString.toString();
	}

	/**
	 * 
	 * @param timeToString
	 * @return
	 */
	public static String TimeToString(Date timeToString) {

		return timeToString.toString();
	}
}
