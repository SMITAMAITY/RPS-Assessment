package com.lti.models;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */

@Entity
@Table(name="sub_category_details")
public class SubCategoryDetails {
	
	@Id
	@Column(name="sub_category_id")
	private int subCategoryId;
	
	@Column(name="sub_category_name")
	private String subCategoryName;
	
	@Column(name="weightage")
	private float weightage;
	
	@Column(name="ideal_score")
	private float idealScore;
	
	@Column(name="ideal_rating")
	private float idealRating;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;
	
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@OneToMany(targetEntity=QuestionDetails.class, cascade=CascadeType.ALL)
	@JoinColumn(name="sub_category_id",referencedColumnName="sub_category_id")
	private List<QuestionDetails> questionDetails;

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public float getWeightage() {
		return weightage;
	}

	public void setWeightage(float weightage) {
		this.weightage = weightage;
	}

	public float getIdealScore() {
		return idealScore;
	}

	public void setIdealScore(float idealScore) {
		this.idealScore = idealScore;
	}

	public float getIdealRating() {
		return idealRating;
	}

	public void setIdealRating(float idealRating) {
		this.idealRating = idealRating;
	}

	public List<QuestionDetails> getQuestionDetails() {
		return questionDetails;
	}

	public void setQuestionDetails(List<QuestionDetails> questionDetails) {
		this.questionDetails = questionDetails;
	}

	public SubCategoryDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SubCategoryDetails(int subCategoryId, String subCategoryName, float weightage, float idealScore,
			float idealRating, List<QuestionDetails> questionDetails) {
		super();
		this.subCategoryId = subCategoryId;
		this.subCategoryName = subCategoryName;
		this.weightage = weightage;
		this.idealScore = idealScore;
		this.idealRating = idealRating;
		this.questionDetails = questionDetails;
	}

	@Override
	public String toString() {
		return "SubCategoryDetails [subCategoryId=" + subCategoryId + ", subCategoryName=" + subCategoryName
				+ ", weightage=" + weightage + ", idealScore=" + idealScore + ", idealRating=" + idealRating
				+ ", questionDetails=" + questionDetails + "]";
	}
	
	
}


