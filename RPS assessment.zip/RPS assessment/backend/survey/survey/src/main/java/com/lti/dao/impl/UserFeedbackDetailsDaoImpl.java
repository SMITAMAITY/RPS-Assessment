package com.lti.dao.impl;

import java.util.List;

import com.lti.dao.IUserFeedbackDetailsDao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.models.UserFeedbackDetails;

/**
 * 
 * @author 10667187
 *
 */

@Repository
public class UserFeedbackDetailsDaoImpl implements IUserFeedbackDetailsDao {
private static final Logger LOGGER = LogManager.getLogger(UserFeedbackDetailsDaoImpl.class);
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	public UserFeedbackDetailsDaoImpl() {

	}

	@Override
	public List<UserFeedbackDetails> readAllUserFeedbackDetails() {
		
		LOGGER.debug("findLastId Start: ");
		String jpql = "From UserFeedbackDetails";
		TypedQuery<UserFeedbackDetails> tquery = entityManager.createQuery(jpql, UserFeedbackDetails.class);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
	
	@Override
	public List<UserFeedbackDetails> readByUserId(int id) {

		LOGGER.debug("readByUserId Start: ");
		String jpql = "select sum(actualRating), idealRating, subcategoryId, userId\r\n" + 
				" from UserFeedbackDetails \r\n" + 
				" where userId = :id and subcategoryId between 1 and 5 \r\n" + 
				"group by subcategoryId";
		
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("id", id);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
	
	@Override
	public List<UserFeedbackDetails> readByUserIdTwo(int id) {
	
		LOGGER.debug("readByUserIdTwo Start: ");
		String jpql = "select sum(actualRating), idealRating, subcategoryId, userId\r\n" + 
				" from UserFeedbackDetails \r\n" + 
				" where userId = :id and subcategoryId between 6 and 8 \r\n" + 
				"group by subcategoryId";
		
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("id", id);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
	
	@Override
	public List<UserFeedbackDetails> readByUserIdThree(int id) {
		
		LOGGER.debug("readByUserIdTwo Start: ");
		String jpql = "select sum(actualRating), idealRating, subcategoryId, userId\r\n" + 
				" from UserFeedbackDetails \r\n" + 
				" where userId = :id and subcategoryId between 9 and 12 \r\n" + 
				"group by subcategoryId";
		
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("id", id);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
	@Override
	public List<UserFeedbackDetails> readByUserIdFour(int id) {
		
		LOGGER.debug("readByUserIdFour Start: ");
		String jpql = "select sum(actualRating), idealRating, subcategoryId, userId\r\n" + 
				" from UserFeedbackDetails \r\n" + 
				" where userId = :id and subcategoryId between 13 and 15 \r\n" + 
				"group by subcategoryId";
		
		Query tquery = entityManager.createQuery(jpql);
		tquery.setParameter("id", id);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

}
