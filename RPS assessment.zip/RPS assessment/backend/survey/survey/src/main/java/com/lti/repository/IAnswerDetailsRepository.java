package com.lti.repository;

/**
 * 
 * @author 10667187
 *
 */
import org.springframework.data.repository.CrudRepository;

import com.lti.models.AnswerDetails;

public interface IAnswerDetailsRepository extends CrudRepository<AnswerDetails, Integer> {

}
