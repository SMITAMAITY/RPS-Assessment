package com.lti.services;

import java.util.List;

import com.lti.models.AnswerDetails;
/**
 * 
 * @author 10667187
 *
 */

public interface IAnswerDetailsService {
	
	List<AnswerDetails> findAllAnswerDetails();
	
	
	void addAnswerDetails(AnswerDetails answerDetails);
}
