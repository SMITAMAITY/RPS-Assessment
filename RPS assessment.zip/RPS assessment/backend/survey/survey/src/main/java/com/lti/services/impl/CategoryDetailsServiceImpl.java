package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.models.CategoryDetails;
import com.lti.repository.ICategoryDetailsRepository;
import com.lti.services.ICategoryDetailsService;
/**
 * 
 * @author 10667188
 *
 */
@Service
public class CategoryDetailsServiceImpl implements ICategoryDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(CategoryDetailsServiceImpl.class);
	
	@Autowired
	private ICategoryDetailsRepository iCategoryDetailsRepository;
	
	@Override
	public List<CategoryDetails> findAllCategoryDetails() {
	
		LOGGER.debug("findAllCategoryDetails Start: ");
		List<CategoryDetails> users = new ArrayList<>();
		iCategoryDetailsRepository.findAll().forEach(users::add);
		
		return users;
	}

	@Override
	public void addCategoryDetails(CategoryDetails categoryDetails) {
		
		LOGGER.debug("addCategoryDetails Start: ");
		iCategoryDetailsRepository.save(categoryDetails);
		LOGGER.debug("addCategoryDetails End: ");
	}
}
