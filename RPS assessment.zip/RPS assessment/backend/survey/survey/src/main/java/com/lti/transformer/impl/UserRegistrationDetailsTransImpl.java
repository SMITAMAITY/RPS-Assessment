package com.lti.transformer.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.lti.commons.XFAConstants;
import com.lti.entity.UserRegistrationDetailsEntity;
import com.lti.entity.UserResponseEntity;
import com.lti.models.UserRegistrationDetails;
import com.lti.utils.XFAUtils;

/**
 * 
 * @author 10653960
 *
 */

@Component
public class UserRegistrationDetailsTransImpl {
	
	private static final Logger LOGGER = LogManager.getLogger(UserRegistrationDetailsTransImpl.class);

	/**
	 * 
	 * @param userRegistrationDetailsEntity
	 * @return
	 */
	public UserRegistrationDetails createUserRegistrationDetailsModel(
			UserRegistrationDetailsEntity userRegistrationDetailsEntity) {

		LOGGER.debug("createuserRegistrationModal Transformation Start: ");
		UserRegistrationDetails userRegistrationDetails = new UserRegistrationDetails();

		userRegistrationDetails.setEmail(userRegistrationDetailsEntity.getEmail());
		userRegistrationDetails.setFullName(userRegistrationDetailsEntity.getFullName());
		userRegistrationDetails.setCompanyName(userRegistrationDetailsEntity.getCompanyName());
		userRegistrationDetails.setCountryRegion(userRegistrationDetailsEntity.getCountryRegion());
		userRegistrationDetails.setJobRole(userRegistrationDetailsEntity.getJobRole());
		userRegistrationDetails.setTotalUserOrg(userRegistrationDetailsEntity.getTotalUserOrg());

		userRegistrationDetails.setCreatedDate(XFAUtils.getTodaysDate());
		userRegistrationDetails.setUpdatedDate(XFAUtils.getTodaysDate());
		userRegistrationDetails.setIsActive(XFAConstants.IS_ACTIVE_Y);

		LOGGER.debug("createuserRegistrationModal Transformation End: ");
		return userRegistrationDetails;
	}

	/**
	 * 
	 * @param userRegistrationDetails
	 * @return
	 */
	public UserResponseEntity setUserResponseEntity(UserRegistrationDetails userRegistrationDetails) {

		LOGGER.debug("setUserResponseEntity Start: ");
		UserResponseEntity userResponseEntity = new UserResponseEntity();
		userResponseEntity.setUserId(userRegistrationDetails.getUserId());
		userResponseEntity.setFullName(userRegistrationDetails.getFullName());
		userResponseEntity.setEmail(userRegistrationDetails.getEmail());

		LOGGER.debug("setUserResponseEntity End: ");
		return userResponseEntity;
	}

}
