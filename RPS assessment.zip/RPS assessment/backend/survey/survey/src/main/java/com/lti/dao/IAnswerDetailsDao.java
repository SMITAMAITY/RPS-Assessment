package com.lti.dao;

import java.util.List;

import com.lti.models.AnswerDetails;
/**
 * 
 * @author 10667187
 *
 */

public interface IAnswerDetailsDao {
	
	//Select details
	List<AnswerDetails> readAllAnswerDetails();
	
	//Insert details
	void createAnswerDetails(AnswerDetails answerDetails);
}


