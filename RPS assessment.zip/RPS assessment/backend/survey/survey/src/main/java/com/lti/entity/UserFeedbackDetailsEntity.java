package com.lti.entity;

import java.io.Serializable;

public class UserFeedbackDetailsEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int questionId;
	
	private int answerId;
	
	private int categoryId;
	
	private int subcategoryId;
	
	private float actualRating;
	
	private float idealRating;
	
	private int userId;
	
	/*
	 * private Date createdDate;
	 * 
	 * private Date updatedDate;
	 * 
	 * private String isActive;
	 */

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public float getActualRating() {
		return actualRating;
	}

	public void setActualRating(float actualRating) {
		this.actualRating = actualRating;
	}

	public float getIdealRating() {
		return idealRating;
	}

	public void setIdealRating(float idealRating) {
		this.idealRating = idealRating;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
