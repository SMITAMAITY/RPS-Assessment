package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.IUserRegistrationDetailsDao;
import com.lti.entity.UserRegistrationDetailsEntity;
import com.lti.entity.UserResponseEntity;
import com.lti.models.UserRegistrationDetails;
import com.lti.repository.IUserRegistrationDetailsRepository;
import com.lti.services.IUserRegistrationDetailsService;
import com.lti.transformer.IUserRegistrationDetailsTrans;
import com.lti.transformer.impl.UserRegistrationDetailsTransImpl;

/**
 * 
 * @author 10667187
 *
 */
@Service
public class UserRegistrationDetailsServiceImpl implements IUserRegistrationDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(UserRegistrationDetailsServiceImpl.class);

	@Autowired
	private IUserRegistrationDetailsRepository iUserRegistrationDetailsRepository;

	@Autowired
	private IUserRegistrationDetailsDao dao;

	@Autowired
	private UserRegistrationDetailsTransImpl trans;

	@Override
	public List<UserRegistrationDetails> findAllUserRegistrationDetails() {

		LOGGER.debug("findAllUserRegistrationDetails Start: ");
		List<UserRegistrationDetails> users = new ArrayList<>();
		iUserRegistrationDetailsRepository.findAll().forEach(users::add);

		return users;
	}

	@Override
	public void addUserRegistrationDetails(UserRegistrationDetails userRegistrationDetails) {

		LOGGER.debug("addUserRegistrationDetails Start: ");
		iUserRegistrationDetailsRepository.save(userRegistrationDetails);
		LOGGER.debug("addUserRegistrationDetails End: ");
	}

	@Override
	public List<UserRegistrationDetails> findLastId() {

		LOGGER.debug("findLastId Start: ");
		return dao.findLastId();
	}

	@Override
	public UserResponseEntity setUserRegistrationDetails(UserRegistrationDetailsEntity userRegistrationDetailsEntity) {

		LOGGER.debug("setUserRegistrationDetails Start: ");
		UserResponseEntity userResponseEntity = new UserResponseEntity();
		UserRegistrationDetails userRegistrationDetails = trans
				.createUserRegistrationDetailsModel(userRegistrationDetailsEntity);
		userRegistrationDetails = iUserRegistrationDetailsRepository.save(userRegistrationDetails);
		userResponseEntity = trans.setUserResponseEntity(userRegistrationDetails);

		return userResponseEntity;
	}
}
