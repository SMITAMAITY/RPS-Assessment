package com.lti.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.CategoryDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface ICategoryDetailsRepository extends CrudRepository<CategoryDetails, Integer> {

}
