package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.IQuestionDetailsDao;
import com.lti.models.QuestionDetails;
import com.lti.repository.IQuestionDetailsRepository;
import com.lti.services.IQuestionDetailsService;
/**
 * 
 * @author 10667187
 *
 */
@Service
public class QuestionDetailsServiceImpl implements IQuestionDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(QuestionDetailsServiceImpl.class);

	@Autowired
	private IQuestionDetailsRepository iQuestionDetailsRepository;
	
	@Autowired
	private IQuestionDetailsDao dao;
	
	@Override
	public List<QuestionDetails> findAllQuestionDetails() {
	
		LOGGER.debug("findAllQuestionDetails Start: ");
		List<QuestionDetails> users = new ArrayList<>();
		iQuestionDetailsRepository.findAll().forEach(users::add);
		
		return users;
	}

	@Override
	public void addQuestionDetails(QuestionDetails questionDetails) {
		
		LOGGER.debug("addQuestionDetails Start: ");
		iQuestionDetailsRepository.save(questionDetails);
		LOGGER.debug("addQuestionDetails End: ");
	}

	@Override
	public List<QuestionDetails> findAllQuestionDetailsByFirstCategory() {
		
		LOGGER.debug("findAllQuestionDetailsByFirstCategory End: ");
		return dao.readQuestionDetailsByFirstCategory();
	}

	@Override
	public List<QuestionDetails> findAllQuestionDetailsBySecondCategory() {
		
		LOGGER.debug("findAllQuestionDetailsBySecondCategory End: ");
		return dao.readQuestionDetailsBySecondCategory();
	}

	@Override
	public List<QuestionDetails> findAllQuestionDetailsByThirdCategory() {
		
		LOGGER.debug("findAllQuestionDetailsByThirdCategory End: ");
		return dao.readQuestionDetailsByThirdCategory();
	}

	@Override
	public List<QuestionDetails> findAllQuestionDetailsByFourthCategory() {
		
		LOGGER.debug("findAllQuestionDetailsByFourthCategory End: ");
		return dao.readQuestionDetailsByFourthCategory();
	}

	@Override
	public List<QuestionDetails> findQuestionDetailsByCategoryId(Integer categoryId) {
		
		LOGGER.debug("findQuestionDetailsByCategoryId End: ");
		return dao.readQuestionDetailsByCategoryId(categoryId);
	}

}