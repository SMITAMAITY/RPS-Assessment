package com.lti.dao.impl;

import java.util.List;

import com.lti.dao.ISubCategoryDetailsDao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.models.SubCategoryDetails;

/**
 * 
 * @author 10667188
 *
 */

@Repository
public class SubCategoryDetailsDaoImpl implements ISubCategoryDetailsDao {

	private static final Logger LOGGER = LogManager.getLogger(SubCategoryDetailsDaoImpl.class);
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	public SubCategoryDetailsDaoImpl() {

	}

	@Override
	public List<SubCategoryDetails> readAllSubCategoryDetails() {
		
		LOGGER.debug("readAllSubCategoryDetails Start: ");
		String jpql = "From SubCategoryDetails";
		TypedQuery<SubCategoryDetails> tquery = entityManager.createQuery(jpql, SubCategoryDetails.class);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

}
