package com.lti.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */
@Entity
@Table(name="user_feedback_details")
public class UserFeedbackDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_feedback_details_id")
	private int userFeedbackDetailsId;
	
	@Column(name="question_id")
	private int questionId;
	
	@Column(name="answer_id")
	private int answerId;
	
	@Column(name="category_id")
	private int categoryId;
	
	@Column(name="subcategory_id")
	private int subcategoryId;
	
	@Column(name="actual_rating")
	private float actualRating;
	
	@Column(name="ideal_rating")
	private float idealRating;
	
	@Column(name="user_id")
	private int userId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;

	public int getUserFeedbackDetailsId() {
		return userFeedbackDetailsId;
	}

	public void setUserFeedbackDetailsId(int userFeedbackDetailsId) {
		this.userFeedbackDetailsId = userFeedbackDetailsId;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public float getActualRating() {
		return actualRating;
	}

	public void setActualRating(float actualRating) {
		this.actualRating = actualRating;
	}

	public float getIdealRating() {
		return idealRating;
	}

	public void setIdealRating(float idealRating) {
		this.idealRating = idealRating;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public UserFeedbackDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserFeedbackDetails(int userFeedbackDetailsId, int questionId, int answerId, int categoryId,
			int subcategoryId, float actualRating, float idealRating, int userId) {
		super();
		this.userFeedbackDetailsId = userFeedbackDetailsId;
		this.questionId = questionId;
		this.answerId = answerId;
		this.categoryId = categoryId;
		this.subcategoryId = subcategoryId;
		this.actualRating = actualRating;
		this.idealRating = idealRating;
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "UserFeedbackDetails [userFeedbackDetailsId=" + userFeedbackDetailsId + ", questionId=" + questionId
				+ ", answerId=" + answerId + ", categoryId=" + categoryId + ", subcategoryId=" + subcategoryId
				+ ", actualRating=" + actualRating + ", idealRating=" + idealRating + ", userId=" + userId + "]";
	}

	
	
	}
