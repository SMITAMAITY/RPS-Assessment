package com.lti.models;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */

@Entity
@Table(name="answer_details")
public class AnswerDetails {
	@Id
	@Column(name="answer_id")
	private int answerId;
	
	@Column(name="answer_description")
	private String answerDescription;
	
	@Column(name="weightage")
	private float weightage;
	
	@Column(name="actual_score")
	private float actualScore;
	
	@Column(name="actual_rating")
	private float actualRating;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;
	

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public int getAnswerId() {
		return answerId;
	}

	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}

	public String getAnswerDescription() {
		return answerDescription;
	}

	public void setAnswerDescription(String answerDescription) {
		this.answerDescription = answerDescription;
	}

	public float getWeightage() {
		return weightage;
	}

	public void setWeightage(float weightage) {
		this.weightage = weightage;
	}

	public float getActualScore() {
		return actualScore;
	}

	public void setActualScore(float actualScore) {
		this.actualScore = actualScore;
	}

	public float getActualRating() {
		return actualRating;
	}

	public void setActualRating(float actualRating) {
		this.actualRating = actualRating;
	}

	public AnswerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AnswerDetails(int answerId, String answerDescription, float weightage, float actualScore,
			float actualRating) {
		super();
		this.answerId = answerId;
		this.answerDescription = answerDescription;
		this.weightage = weightage;
		this.actualScore = actualScore;
		this.actualRating = actualRating;
	}

	@Override
	public String toString() {
		return "AnswerDetails [answerId=" + answerId + ", answerDescription=" + answerDescription + ", weightage="
				+ weightage + ", actualScore=" + actualScore + ", actualRating=" + actualRating + "]";
	}
	
	
	
	
	
}
