package com.lti.commons;

/**
 * 
 * @author 10653960
 *
 */
public class XFAConstants {

	public static String IS_ACTIVE_Y = "Y";
	public static String IS_ACTIVE_N = "N";

	public static String DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
	public static String DATE_FORMAT = "yyyy/MM/dd";
	public static String TIME_FORMAT = "HH:mm:ss";

	public static String SENDER_MAIL_ADDRESS = "mrityunjoy.laha@lntinfotech.com"; //TODO change Email ID
	public static String BUSINESS_USER_MAIL_ADDRESS = "mohan.patil@lntinfotech.com,Arul.Raj@lntinfotech.com,SubhraShankar.Banerjee@lntinfotech.com,Collins.Daniel@lntinfotech.com,Sathishkumar.Jothimani@lntinfotech.com";

	public static String MAIL_SUBJECT_TEXT = "Your Remote Proximity Digital Workplace Online Assessment report from LTI"; // TODO
	public static String MAIL_BODY_TEXT_NAME = "Hi ";
	public static String MAIL_BODY_TEXT_DET = "\n\nWe would like to thank you for your valuable time that you spent to take LTI's Remote Proximity Digital Workplace Online Assessment. "
			+ "\n\nPlease find attached the report of the assessment for your review."
			+ "\n\nFurther to this, we encourage you to write back to us should you have any questions on the report and we would be glad to setup a 1 hour free consultation with our experts."
			+ "\n\n\nLTI Remote Proximity Services Team";

}
