package com.lti.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.UserFeedbackDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface IUserFeedbackDetailsRepository extends CrudRepository<UserFeedbackDetails, Integer>  {
	
	List<UserFeedbackDetails> findBysubcategoryId(int subcategoryId);
}
