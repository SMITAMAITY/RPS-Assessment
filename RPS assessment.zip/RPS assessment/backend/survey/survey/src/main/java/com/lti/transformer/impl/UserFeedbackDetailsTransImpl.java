package com.lti.transformer.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.lti.commons.XFAConstants;
import com.lti.models.UserFeedbackDetails;
import com.lti.transformer.IUserFeedbackDetailsTrans;
import com.lti.utils.XFAUtils;

/**
 * 
 * @author 10667187
 *
 */
@Component
public class UserFeedbackDetailsTransImpl implements IUserFeedbackDetailsTrans {

	private static final Logger LOGGER = LogManager.getLogger(UserFeedbackDetailsTransImpl.class);

	
	
	public List<UserFeedbackDetails> saveUserFeedbackDetails(
			List<UserFeedbackDetails> userFeedbackDetailsList) {

		LOGGER.debug("saveUserFeedbackDetails Transformation Start: ");
		List<UserFeedbackDetails> userFeedbackDetailsListUpdate = new ArrayList<UserFeedbackDetails>();
		
		for(UserFeedbackDetails userFeedbackDetails: userFeedbackDetailsList) {
			
			UserFeedbackDetails userFeedbackDetailsUpdate = new UserFeedbackDetails();
	
			userFeedbackDetailsUpdate.setUserId(userFeedbackDetails.getUserId());
			userFeedbackDetailsUpdate.setAnswerId(userFeedbackDetails.getAnswerId());
			userFeedbackDetailsUpdate.setQuestionId(userFeedbackDetails.getQuestionId());
			userFeedbackDetailsUpdate.setCategoryId(userFeedbackDetails.getCategoryId());
			userFeedbackDetailsUpdate.setSubcategoryId(userFeedbackDetails.getSubcategoryId());
			userFeedbackDetailsUpdate.setActualRating(userFeedbackDetails.getActualRating());
			userFeedbackDetailsUpdate.setIdealRating(userFeedbackDetails.getIdealRating());
	
			userFeedbackDetailsUpdate.setCreatedDate(XFAUtils.getTodaysDate());
			userFeedbackDetailsUpdate.setUpdatedDate(XFAUtils.getTodaysDate());
			userFeedbackDetailsUpdate.setIsActive(XFAConstants.IS_ACTIVE_Y);
			
			userFeedbackDetailsListUpdate.add(userFeedbackDetailsUpdate);
		}

		LOGGER.debug("saveUserFeedbackDetails Transformation End: ");
		return userFeedbackDetailsListUpdate;
	}
}
