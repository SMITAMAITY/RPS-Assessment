package com.lti.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.QuestionDetails;
/**
 * 
 * @author 10667187
 *
 */

public interface IQuestionDetailsRepository extends CrudRepository<QuestionDetails, Integer>  {

}
