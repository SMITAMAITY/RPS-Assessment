package com.lti.transformer;

import java.util.List;

import com.lti.models.UserFeedbackDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface IUserFeedbackDetailsTrans {


	/**
	 * 
	 * @param userFeedbackDetailsList
	 * @return
	 */
	List<UserFeedbackDetails> saveUserFeedbackDetails(List<UserFeedbackDetails> userFeedbackDetailsList);
}
