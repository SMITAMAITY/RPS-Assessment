package com.lti.controllers;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.models.AnswerDetails;
import com.lti.services.impl.AnswerDetailsServiceImpl;

/**
 * 
 * @author 10667187
 *
 */
@RestController
@CrossOrigin
public class AnswerDetailsController {
	
	private static final Logger LOGGER = LogManager.getLogger(AnswerDetailsController.class);

	@Autowired //how spring will know that it is a dependency
	private AnswerDetailsServiceImpl answerDetailsServiceImpl;
	
	/**
	 * 
	 * @return
	 */
	@RequestMapping(value ="/AnswerDetails", method = RequestMethod.GET)
	public List<AnswerDetails> getAnswerDetails(){
		
		LOGGER.debug("getAnswerDetailss Start: ");
		return answerDetailsServiceImpl.findAllAnswerDetails();
	}
	
	/**
	 * 
	 * @param answerDetails
	 */
	@RequestMapping(value ="/AnswerDetails", method = RequestMethod.POST)
	public void saveAnswerDetails(@RequestBody AnswerDetails answerDetails) {
		
		LOGGER.debug("saveAnswerDetails Start: ");
		answerDetailsServiceImpl.addAnswerDetails(answerDetails);
	}
}
