package com.lti.dao;

import java.util.List;

import com.lti.models.UserRegistrationDetails;

/**
 * 
 * @author 10667187
 *
 */

public interface IUserRegistrationDetailsDao {

	//Select details
	List<UserRegistrationDetails> readAllUserRegistrationDetails();

	//Insert details
	void createUserRegistrationDetails(UserRegistrationDetails userRegistrationDetails);
	
	List<UserRegistrationDetails> findLastId();
}
