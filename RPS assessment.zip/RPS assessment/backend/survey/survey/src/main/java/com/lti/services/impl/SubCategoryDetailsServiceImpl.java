package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.models.SubCategoryDetails;
import com.lti.repository.ISubCategoryDetailsRepository;
import com.lti.services.ISubCategoryDetailsService;
/**
 * 
 * @author 10667187
 *
 */
@Service
public class SubCategoryDetailsServiceImpl implements ISubCategoryDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(SubCategoryDetailsServiceImpl.class);
	
	@Autowired
	private ISubCategoryDetailsRepository iSubCategoryDetailsRepository;
	
	@Override
	public List<SubCategoryDetails> findAllSubCategoryDetails() {
		
		LOGGER.debug("findAllSubCategoryDetails Start: ");
		List<SubCategoryDetails> users = new ArrayList<>();
		iSubCategoryDetailsRepository.findAll().forEach(users::add);
		
		return users;
	}

	@Override
	public void addSubCategoryDetails(SubCategoryDetails subCategoryDetails) {
		
		LOGGER.debug("addSubCategoryDetails Start: ");
		iSubCategoryDetailsRepository.save(subCategoryDetails);
		LOGGER.debug("addSubCategoryDetails End: ");
	}

}
