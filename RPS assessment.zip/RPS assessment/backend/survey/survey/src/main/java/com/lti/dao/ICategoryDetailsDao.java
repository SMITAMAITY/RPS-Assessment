package com.lti.dao;

import java.util.List;

import com.lti.models.CategoryDetails;
/**
 * 
 * @author 10667187
 *
 */

public interface ICategoryDetailsDao {

	//Select details
	List<CategoryDetails> readAllCategoryDetails();
}
