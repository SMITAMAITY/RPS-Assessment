package com.lti.transformer;

import com.lti.entity.UserRegistrationDetailsEntity;
import com.lti.entity.UserResponseEntity;
import com.lti.models.UserRegistrationDetails;
/**
 * 
 * @author 10667187
 *
 */
public interface IUserRegistrationDetailsTrans {
	
	/**
	 * 
	 * @param userRegistrationDetailsEntity
	 * @return
	 */
	UserRegistrationDetails createUserRegistrationDetailsModel(UserRegistrationDetailsEntity userRegistrationDetailsEntity );
	
	/**
	 * 
	 * @param userRegistrationDetails
	 * @return
	 */
	UserResponseEntity setUserResponseEntity(UserRegistrationDetails userRegistrationDetails);
}
