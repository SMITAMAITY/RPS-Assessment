package com.lti.services;

import java.util.List;

import com.lti.models.QuestionDetails;
/**
 * 
 * @author 10667187
 *
 */
public interface IQuestionDetailsService {
	
	List<QuestionDetails> findAllQuestionDetails();
	
	void addQuestionDetails(QuestionDetails questionDetails);

	List<QuestionDetails> findAllQuestionDetailsByFirstCategory();
	
	List<QuestionDetails> findAllQuestionDetailsBySecondCategory();
	
	List<QuestionDetails> findAllQuestionDetailsByThirdCategory();
	
	List<QuestionDetails> findAllQuestionDetailsByFourthCategory();
	 
	List<QuestionDetails> findQuestionDetailsByCategoryId(Integer categoryId);
}
