package com.lti.transformer.impl;

import javax.mail.internet.InternetAddress;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//import javax.activation.DataSource;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

import com.lti.commons.XFAConstants;
import com.lti.entity.OutcomeFileDetailsEntity;
import com.lti.transformer.ICreateEmailTrans;

/**
 * 
 * @author 10653960
 *
 */
@Component
public class CreateEmailTransImpl implements ICreateEmailTrans {

	private static final Logger LOGGER = LogManager.getLogger(CreateEmailTransImpl.class);
	private JavaMailSender mailSender;

	/**
	 * 
	 * @param mailSender
	 */
	public CreateEmailTransImpl(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * 
	 */
	public void prepareAndSend(OutcomeFileDetailsEntity outcomeFileDetailsEntity) {

		MimeMessagePreparator messagePreparator = mimeMessage -> {

			LOGGER.debug("Mails Prepartion start");
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true);

			InternetAddress[] myBccList = InternetAddress.parse(XFAConstants.BUSINESS_USER_MAIL_ADDRESS);

			messageHelper.setFrom(XFAConstants.SENDER_MAIL_ADDRESS);
			// messageHelper.setBcc(myBccList);
			messageHelper.setSubject(XFAConstants.MAIL_SUBJECT_TEXT);

			if (null != outcomeFileDetailsEntity) {

				String mailBodyText = XFAConstants.MAIL_BODY_TEXT_NAME + outcomeFileDetailsEntity.getFullName() + ", "
						+ XFAConstants.MAIL_BODY_TEXT_DET;

				messageHelper.setText(mailBodyText);

				messageHelper.setTo(InternetAddress.parse(outcomeFileDetailsEntity.getEmail()));

				messageHelper.addAttachment("RPSAssessment.pdf", outcomeFileDetailsEntity.getBlobDetailsIng());
			}
			LOGGER.debug("Mails Prepartion complete");
		};

		try {

			mailSender.send(messagePreparator);
			LOGGER.debug("Mails sent successfully.");
		} catch (MailException mailException) {

			LOGGER.error("There is an error in mails sending: " + mailException.getMessage());
		}
	}
}
