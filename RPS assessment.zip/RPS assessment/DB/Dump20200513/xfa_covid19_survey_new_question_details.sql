-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: xfa_covid19_survey_new
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question_details`
--

DROP TABLE IF EXISTS `question_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_details` (
  `question_id` int NOT NULL,
  `question_description` varchar(255) DEFAULT NULL,
  `sub_category_id` int DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `is_active` varchar(255) DEFAULT NULL,
  `updated_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`question_id`),
  KEY `FKslx0r23j6qqctfk8c0ah7uf9` (`sub_category_id`),
  CONSTRAINT `FKslx0r23j6qqctfk8c0ah7uf9` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_category_details` (`sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_details`
--

LOCK TABLES `question_details` WRITE;
/*!40000 ALTER TABLE `question_details` DISABLE KEYS */;
INSERT INTO `question_details` VALUES (1,'Are your employees provided with any form of end point device like desktop, laptop, BYOD, thin client or virtual desktops (VDIs) for accessing the corporate services from office location or working remotely?(Productivity Related)',1,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(2,'Do you have BYOD policy in permanent use currently? (Productivity and User Experience Related)',2,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(3,'What percentage of users are leveraging BYOD options? (Productivity and User Experience Related)',2,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(4,'Do you have  users who are accessing corporate services through remote connections? (Productivity and User Experience Related)',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(5,'During normal situations what are the standard methods the remote users are using for accessing corporate services? (Productivity and User Experience Related)',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(6,'During the current pandemic situation how have you enabled the remote users to access the corporate services. (Productivity and User Experience Related) ',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(7,'If BYOD devices with corporate images are being used on short term basis during pandemic situation, do you have a plan to sustain the same model on a permanent basis once the pandemic is over?  (User Experience Related)',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(8,'Are you able to provide consistent user experience with the short-term solutions being used by remote users? (User Experience Related)',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(9,'What were the other challenges faced with the short-term solutions for remote users? (User Experience Related)',3,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(10,'Do you have VDI solution in place currently ? (Productivity Related)',4,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(11,'If you have existing VDI solution, what type of VDI patterns are offered? (Productivity Related)',4,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(12,'Do you have common operating environment or a managed operating environment (Personalization Related)',5,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(13,'How do you standardize operating images currently? (Productivity Related)',5,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(14,'Communication & Collaboration tools are from a single Product suite and is fully integrated to provide various aspects of the collaboration experience. (Productivity Related)',6,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(15,'What kind of platform model is used for hosting your Unified Communication & Collaboration tools? (Scalability and Productivity Related)',6,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(16,'Do you have a unified communication tool which can provide all channels of communication - Voice/VOIP calls, Chat/Messaging, Meetings, Audio/web/video conferencing? (Productivity Related)',6,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(17,'Unified communication tools are used by all employees for IM , Voice , Video and meetings regularly ? (Productivity and User Experience Related)',6,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(18,'What is the primary factor impacting the end-user experience in using Unified Communication platform? (User Experience Related)',7,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(19,'Collaboration platforms like file/content sharing, work place networking are used by all employees routinely. (Productivity Related)',7,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(20,'Majority of the employees can access email, calendar, unified communication features and intranet services using mobile.  (Productivity and User Experience Related)',7,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(21,'Do you have a strategy for continuous evaluation of your collaboration platform for enhancing user experience, resiliency and cost effectiveness? (Productivity and User Experience Related)',8,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(22,'Do you believe that user training on technology deployed for remote working is needed? (User Experience Related)',9,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(23,'What sort of Digital Channels have been deployed for the users? (User Experience Related)',9,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(24,'Despite having an offline mode of support for remote working, do you see a spike in volumes at the Service Desk? (User Experience Related)',10,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(25,'Are you prepared to manage the spike in volumes? (User Experience Related)',10,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(26,'Have you implemented persona based services? (Personalization Related)',11,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(27,'What services are tuned to support persona based categorization? (Personalization Related)',11,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(28,'Is your user environment being monitored for user experience? (User Experience Related)',12,'2020-05-13 11:53:15.000000','v','2020-05-13 11:53:15.000000'),(29,'Given the business continuity situation of most users working remotely, what is your strategy for onboarding new hires/ Contractors? (Productivity Related)',12,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(30,'What percentage of users are able to connect remotely during normal situations using secure VPN solutions? (Security and Productivity Related)',13,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(31,'In a BCP situation, are users able to connect remotely in a seamless manner using existing secure VPN solutions? (Security and Productivity Related)',13,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(32,'What different solutions are deployed for users to access internal applications securely from outside the organization? (Security Related)',14,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(33,'Do you have end to end coverage of security pertaining to Identity and device management  (Security Related)',15,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000'),(34,'What modules of end point protection are enabled?  (Security Related)',15,'2020-05-13 11:53:15.000000','Y','2020-05-13 11:53:15.000000');
/*!40000 ALTER TABLE `question_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-13 12:51:46
