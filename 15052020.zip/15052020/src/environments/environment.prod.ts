export const environment = {

  production: true,

  //172.20.97.65
  //apiUrl: 'http://172.20.97.16:8080/',
  apiUrl: 'http://localhost:8080',
  //apiUrl: 'https://informdev.isg-one.com:8443/',
  // apiUrl: 'https://isgintellisourceqaws.isg-one.com:8443/',
};
