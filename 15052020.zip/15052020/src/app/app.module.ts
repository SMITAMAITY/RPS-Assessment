import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { NgApexchartsModule } from "ng-apexcharts";
import { WelcomeComponent } from './welcome/welcome.component';
import { RegisterComponent } from './register/register.component';
import { DeviceComponent } from './device/device.component';
import { SecureConnectivityComponent } from './secure-connectivity/secure-connectivity.component';
import { SmartServicesComponent } from './smart-services/smart-services.component';
import { CollaborationComponent } from './collaboration/collaboration.component';
import { GraphComponent } from './graph/graph.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    RegisterComponent,
    DeviceComponent,
    SecureConnectivityComponent,
    SmartServicesComponent,
    CollaborationComponent,
    GraphComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgApexchartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
