export const SurveyURLProperties = {

  USER_REGISTRATION_DETAILS: 'UserRegistrationDetails',

  CATEGORY_DETAILS: 'CategoryDetails',

  QUESTION_DETAILS_COLLABORATION: 'QuestionDetails/Collaboration',

  USER_FEEDBACK_DETAILS_CATEGORY_ONE: 'UserFeedbackDetails/CategoryOne/',
  USER_FEEDBACK_DETAILS_CATEGORY_TWO: 'UserFeedbackDetails/CategoryTwo/',
  USER_FEEDBACK_DETAILS_CATEGORY_THREE: 'UserFeedbackDetails/CategoryThree/',
  USER_FEEDBACK_DETAILS_CATEGORY_FOUR: 'UserFeedbackDetails/CategoryFour/',

  USER_FEEDBACK_DETAILS: 'UserFeedbackDetails',

  SHARE_OUTCOME_GRAPH_WITH_USER: "sharedOutcomeWithUser"
}
