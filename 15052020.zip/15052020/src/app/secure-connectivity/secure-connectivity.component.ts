import { SurveyService } from './../services/survey.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-secure-connectivity',
  templateUrl: './secure-connectivity.component.html',
  styleUrls: ['./secure-connectivity.component.css']
})
export class SecureConnectivityComponent implements OnInit {

  secureconnectivityData:any;

  constructor(private http:HttpClient, private router: Router, private formBuilder: FormBuilder, public surveyService: SurveyService) {

  }

  ngOnInit() {

    this.secureconnectivityData = this.surveyService.getallData();
    console.log(this.secureconnectivityData);
  }

  continue() {

    this.router.navigate(['collaboration']);
  }


  ngOnDestroy(): void {

    this.surveyService.setallData(this.secureconnectivityData);
  }
}
