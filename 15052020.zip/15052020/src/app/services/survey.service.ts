import { HttpClient, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { SurveyURLProperties } from './../properties/survey-url-properties';

@Injectable({
  providedIn: 'root'
})
export class SurveyService {
 quizData : any = {};
 storeData : any = {};
 allData : any = [];
 dataFetched : boolean = false;

 urlUserFeedbackDetails:string = environment.apiUrl + SurveyURLProperties.USER_FEEDBACK_DETAILS;
 urlCategoryDetails:string = environment.apiUrl + SurveyURLProperties.CATEGORY_DETAILS;
 urlShareGraphToUser:string = environment.apiUrl + SurveyURLProperties.SHARE_OUTCOME_GRAPH_WITH_USER;

 smartservicesData:any;
  z1:any;
  a:any;
  res:any;
 newarray:any =[];
 count:any = 0;

constructor(private http:HttpClient, private router: Router) { }

fetchData ():any{

  if(this.dataFetched) {

    return of(this.allData);
  } else {
    return this.http.get(this.urlCategoryDetails).pipe(
          tap((data) => {
            this.allData = data;
            console.log("Service data :"+this.allData);
            this.dataFetched = true;
          }),
      );
  }
}

sendData(): any{
  this.smartservicesData = this.getallData();
  console.log(this.smartservicesData);


  console.log(this.smartservicesData.length);


  for (let index = 0; index < this.smartservicesData.length; index++) {

    for(let j=0;j<this.smartservicesData[index].subCategoryDetails.length;j++){


        for(let k=0;k<this.smartservicesData[index].subCategoryDetails[j].questionDetails.length;k++){

         let b = this.smartservicesData[index].subCategoryDetails[j].questionDetails[k].selectedAnswer;

         if(b >= 0)
         {this.count++;
         }
        }
      }
    }

    console.log(this.count);

  this.z1 = Number(localStorage.getItem('userId'));


  if(this.count==34)
  {
  for (let index = 0; index < this.smartservicesData.length; index++) {

    for(let j=0;j<this.smartservicesData[index].subCategoryDetails.length;j++){


        for(let k=0;k<this.smartservicesData[index].subCategoryDetails[j].questionDetails.length;k++){

          this.a = this.smartservicesData[index].subCategoryDetails[j].questionDetails[k].selectedAnswer;
          console.log(this.a);

          this.newarray.push({questionId: this.smartservicesData[index].subCategoryDetails[j].questionDetails[k].questionId,
           answerId:this.smartservicesData[index].subCategoryDetails[j].questionDetails[k].answerDetails[this.a].answerId,
            idealRating: this.smartservicesData[index].subCategoryDetails[j].idealRating,
             actualRating:this.smartservicesData[index].subCategoryDetails[j].questionDetails[k].answerDetails[this.a].actualRating,
             categoryId :this.smartservicesData[index].categoryId,
             subcategoryId: this.smartservicesData[index].subCategoryDetails[j].subCategoryId,
             userId:Number(this.z1)})
          }
      }
  }

  this.http.post(this.urlUserFeedbackDetails, this.newarray).subscribe(data => {

    this.res = data;
    console.log( this.res);

    this.router.navigate(['graph']);
  });



}else{
  alert('Complete all the questions');
  this.count = 0;
 this.router.navigate(['smartServices']);
}

  console.log(this.newarray);

}




getallData():any{
return this.allData;
}

setallData(data):any{
  this.allData = data;
}


uploadFile(formData: FormData) {
  const httpRequest = new HttpRequest('POST', this.urlShareGraphToUser, formData);
  return this.http.request(httpRequest);
}

}
