import {HttpClient} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { SurveyURLProperties } from './../properties/survey-url-properties';

export class SurveyManagementService {

  private APIURL:string;

  private USER_REGISTRATION:string;

  private CATEGORY_DETAILS:string;

  private QUESTION_DETAILS_COLLABORATION:string;

  private USER_FEEDBACK_DETAILS_CATEGORY_ONE:string;
  private USER_FEEDBACK_DETAILS_CATEGORY_TWO:string;
  private USER_FEEDBACK_DETAILS_CATEGORY_THREE:string;
  private USER_FEEDBACK_DETAILS_CATEGORY_FOUR:string;

  private USER_FEEDBACK_DETAILS:string;

  private SHARE_OUTCOME_GRAPH_WITH_USER:string;


  constructor(private http:HttpClient) {

    this.APIURL = environment.apiUrl;

    this.USER_REGISTRATION = SurveyURLProperties.USER_REGISTRATION_DETAILS;

    this.CATEGORY_DETAILS = SurveyURLProperties.CATEGORY_DETAILS;

    this.QUESTION_DETAILS_COLLABORATION = SurveyURLProperties.QUESTION_DETAILS_COLLABORATION;

    this.USER_FEEDBACK_DETAILS_CATEGORY_ONE = SurveyURLProperties.USER_FEEDBACK_DETAILS_CATEGORY_ONE;
    this.USER_FEEDBACK_DETAILS_CATEGORY_TWO = SurveyURLProperties.USER_FEEDBACK_DETAILS_CATEGORY_TWO;
    this.USER_FEEDBACK_DETAILS_CATEGORY_THREE = SurveyURLProperties.USER_FEEDBACK_DETAILS_CATEGORY_THREE;
    this.USER_FEEDBACK_DETAILS_CATEGORY_FOUR = SurveyURLProperties.USER_FEEDBACK_DETAILS_CATEGORY_FOUR;

    this.USER_FEEDBACK_DETAILS = SurveyURLProperties.USER_FEEDBACK_DETAILS;

    this.SHARE_OUTCOME_GRAPH_WITH_USER = SurveyURLProperties.SHARE_OUTCOME_GRAPH_WITH_USER;
  }

  public saveUserDetails(){
    return this.http.get(this.APIURL+this.USER_REGISTRATION);
  }

  public getCategoryDetails(){
    return this.http.get(this.APIURL+this.CATEGORY_DETAILS);
  }

  public getCollaborationQuestions(){
    return this.http.get(this.APIURL+this.QUESTION_DETAILS_COLLABORATION);
  }

  public getUserFeedbackCategoryOne(){
    return this.http.get(this.APIURL+this.USER_FEEDBACK_DETAILS_CATEGORY_ONE);
  }

  public getUserFeedbackCategoryTwo(){
    return this.http.get(this.APIURL+this.USER_FEEDBACK_DETAILS_CATEGORY_TWO);
  }

  public getUserFeedbackCategoryThree(){
    return this.http.get(this.APIURL+this.USER_FEEDBACK_DETAILS_CATEGORY_THREE);
  }

  public getUserFeedbackCategoryFour(){
    return this.http.get(this.APIURL+this.USER_FEEDBACK_DETAILS_CATEGORY_FOUR);
  }

  public getUserFeedbackDetails(){
    return this.http.get(this.APIURL+this.USER_FEEDBACK_DETAILS);
  }

  public shareAssessmentOutcomeDetails(){
    return this.http.get(this.APIURL+this.SHARE_OUTCOME_GRAPH_WITH_USER);
  }
}
