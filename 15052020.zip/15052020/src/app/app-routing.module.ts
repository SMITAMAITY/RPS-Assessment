import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { RegisterComponent } from './register/register.component';
import { DeviceComponent } from './device/device.component';
import { SecureConnectivityComponent } from './secure-connectivity/secure-connectivity.component';
import { SmartServicesComponent } from './smart-services/smart-services.component';
import { CollaborationComponent } from './collaboration/collaboration.component';
import { GraphComponent } from './graph/graph.component';


const routes: Routes = [
  {path:'', component:WelcomeComponent},
  {path:'register', component:RegisterComponent},
  {path:'device', component:DeviceComponent},
  {path:'secureConnectivity', component:SecureConnectivityComponent},
  {path:'smartServices', component:SmartServicesComponent},
  {path:'collaboration', component:CollaborationComponent},
  {path:'graph', component:GraphComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
