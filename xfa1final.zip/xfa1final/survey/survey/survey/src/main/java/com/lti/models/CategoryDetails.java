package com.lti.models;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */

@Entity
@Table(name="category_details")
public class CategoryDetails {
	@Id
	@Column(name="category_id")
	private int categoryId;
	
	@Column(name="category_description")
	private String categoryDescription;
	
	@Column(name="final_ideal_rating")
	private float finalIdealRating;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;
	
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@OneToMany(targetEntity=SubCategoryDetails.class, cascade=CascadeType.ALL)
	@JoinColumn(name="category_id",referencedColumnName="category_id")
	private List<SubCategoryDetails> subCategoryDetails;

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryDescription() {
		return categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public float getFinalIdealRating() {
		return finalIdealRating;
	}

	public void setFinalIdealRating(float finalIdealRating) {
		this.finalIdealRating = finalIdealRating;
	}

	public List<SubCategoryDetails> getSubCategoryDetails() {
		return subCategoryDetails;
	}

	public void setSubCategoryDetails(List<SubCategoryDetails> subCategoryDetails) {
		this.subCategoryDetails = subCategoryDetails;
	}

	public CategoryDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryDetails(int categoryId, String categoryDescription, float finalIdealRating,
			List<SubCategoryDetails> subCategoryDetails) {
		super();
		this.categoryId = categoryId;
		this.categoryDescription = categoryDescription;
		this.finalIdealRating = finalIdealRating;
		this.subCategoryDetails = subCategoryDetails;
	}

	@Override
	public String toString() {
		return "CategoryDetails [categoryId=" + categoryId + ", categoryDescription=" + categoryDescription
				+ ", finalIdealRating=" + finalIdealRating + ", subCategoryDetails=" + subCategoryDetails + "]";
	}

	
	
}
