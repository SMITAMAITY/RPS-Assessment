package com.lti.services;

import java.util.List;

import com.lti.models.CategoryDetails;
/**
 * 
 * @author 10667187
 *
 */
public interface ICategoryDetailsService {

	List<CategoryDetails> findAllCategoryDetails();
	
	void addCategoryDetails(CategoryDetails categoryDetails);
}
