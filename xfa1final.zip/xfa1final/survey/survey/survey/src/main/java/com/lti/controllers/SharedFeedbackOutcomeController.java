package com.lti.controllers;

import javax.servlet.annotation.MultipartConfig;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.lti.entity.OutcomeFileDetailsEntity;
import com.lti.services.ISharedFeedbackOutcomeService;

/**
 * 
 * @author 10667187
 *
 */


@RestController
@CrossOrigin
@MultipartConfig(maxFileSize = 1024*1024*1024, maxRequestSize = 1024*1024*1024)
public class SharedFeedbackOutcomeController {

	@Autowired
	ISharedFeedbackOutcomeService sharedFeedbackOutcomeServiceImpl;
	
	private static final Logger LOGGER = LogManager.getLogger(SharedFeedbackOutcomeController.class);

	/**
	 * 
	 * @param outcomeFileDetailsEntity
	 */
	

	@RequestMapping(value = "/sharedOutcomeWithUser", method = RequestMethod.POST, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE, MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE } )
	public void saveUserFeedbackDetails( @RequestPart("email") String emails, 
			@RequestPart("fullName") String fullName, @RequestPart("blobDetailsIng") MultipartFile blobDetailsIng) {
		
		OutcomeFileDetailsEntity outcomeFileDetailsEntity = new OutcomeFileDetailsEntity();
		LOGGER.debug("outcomeFileDetailsEntity. Email: " + emails);
		outcomeFileDetailsEntity.setEmail(emails);
		outcomeFileDetailsEntity.setBlobDetailsIng(blobDetailsIng);
		outcomeFileDetailsEntity.setFullName(fullName);
		sharedFeedbackOutcomeServiceImpl.prepareAndSend(outcomeFileDetailsEntity);
		LOGGER.debug("Mails sent successfully");
	}
	
}
