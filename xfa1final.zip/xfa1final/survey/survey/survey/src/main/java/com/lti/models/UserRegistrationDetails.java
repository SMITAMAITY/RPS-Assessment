package com.lti.models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */
@Entity
@Table(name="user_registration_details")
public class UserRegistrationDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="user_id")
	private int userId;
	
	@Column(name="full_name")
	private String fullName;

	@Column(name="company_name")
	private String companyName;
	
	
	@Column(name="email", unique=true)
	private String email;
	
	@Column(name="job_role")
	private String jobRole;

	@Column(name="total_user_org")
	private int totalUserOrg;

	@Column(name="country_region")
	private String countryRegion;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;
	
	@OneToMany(targetEntity=UserFeedbackDetails.class, cascade=CascadeType.ALL)
	@JoinColumn(name="user_id",referencedColumnName="user_id")
	private List<UserFeedbackDetails> UserFeedbackDetails = new ArrayList<UserFeedbackDetails>();

	public List<UserFeedbackDetails> getUserFeedbackDetails() {
		return UserFeedbackDetails;
	}

	public void setUserFeedbackDetails(List<UserFeedbackDetails> userFeedbackDetails) {
		UserFeedbackDetails = userFeedbackDetails;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public int getTotalUserOrg() {
		return totalUserOrg;
	}

	public void setTotalUserOrg(int totalUserOrg) {
		this.totalUserOrg = totalUserOrg;
	}

	public String getCountryRegion() {
		return countryRegion;
	}

	public void setCountryRegion(String countryRegion) {
		this.countryRegion = countryRegion;
	}

//	public List<UserFeedbackDetails> getUserFeedbackDetails() {
//		return UserFeedbackDetails;
//	}
//
//	public void setUserFeedbackDetails(List<UserFeedbackDetails> userFeedbackDetails) {
//		UserFeedbackDetails = userFeedbackDetails;
//	}

	public UserRegistrationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRegistrationDetails(int userId, String fullName, String companyName, String email, String jobRole, int totalUserOrg,
			String countryRegion) {
		super();
		this.userId = userId;
		this.fullName = fullName;
		this.companyName = companyName;
		this.email = email;
		this.jobRole = jobRole;
		this.totalUserOrg = totalUserOrg;
		this.countryRegion = countryRegion;
//		UserFeedbackDetails = userFeedbackDetails;
	}

	@Override
	public String toString() {
		return "Registration [userId=" + userId + ", fullName=" + fullName + ", companyName=" + companyName + ", email="
				+ email + ", jobRole=" + jobRole + ", totalUserOrg=" + totalUserOrg + ", countryRegion=" + countryRegion
				+ "]";
	}

	





}
