package com.lti.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.IUserRegistrationDetailsDao;
import com.lti.models.UserRegistrationDetails;

/**
 * 
 * @author 10667187
 *
 */
@Repository
public class UserRegistrationDetailsDaoImpl implements IUserRegistrationDetailsDao {
private static final Logger LOGGER = LogManager.getLogger(UserRegistrationDetailsDaoImpl.class);
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	public UserRegistrationDetailsDaoImpl() {

	}
	
	@Override
	public List<UserRegistrationDetails> readAllUserRegistrationDetails() {

		LOGGER.debug("readAllUserRegistrationDetails Start: ");
		String jpql = "From UserRegistrationDetails";
		TypedQuery<UserRegistrationDetails> tquery = entityManager.createQuery(jpql, UserRegistrationDetails.class);
		return tquery.getResultList();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void createUserRegistrationDetails(UserRegistrationDetails userRegistrationDetails) {

		LOGGER.debug("createUserRegistrationDetails Start: ");
		// TODO Auto-generated method stub
		entityManager.persist(userRegistrationDetails);
	}

	@Override
	public List<UserRegistrationDetails> findLastId() {
		
		LOGGER.debug("findLastId Start: ");
		String jpql = "select max(t.userId) from UserRegistrationDetails t";
		Query  tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		return tquery.getResultList();
	}

}
