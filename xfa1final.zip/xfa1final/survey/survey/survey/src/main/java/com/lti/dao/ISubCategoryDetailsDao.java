package com.lti.dao;

import java.util.List;

import com.lti.models.SubCategoryDetails;

/**
 * 
 * @author 10667187
 *
 */

public interface ISubCategoryDetailsDao {

	//Select details
	List<SubCategoryDetails> readAllSubCategoryDetails();

}
