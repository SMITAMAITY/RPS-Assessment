package com.lti.dao;

import java.util.List;

import com.lti.models.UserFeedbackDetails;

/**
 * 
 * @author 10667187
 *
 */

public interface IUserFeedbackDetailsDao {
	
	//Select details
	List<UserFeedbackDetails> readAllUserFeedbackDetails();

	//Fetch Actual and Ideal rating according to subcategory 1 to 5
	List<UserFeedbackDetails> readByUserId(int id);
	
	//Fetch Actual and Ideal rating according to subcategory 6 to 8
	List<UserFeedbackDetails> readByUserIdTwo(int id);
	
	//Fetch Actual and Ideal rating according to subcategory 9 to 12
	List<UserFeedbackDetails> readByUserIdThree(int id);
	
	//Fetch Actual and Ideal rating according to subcategory 13 to 15
	List<UserFeedbackDetails> readByUserIdFour(int id);
}
