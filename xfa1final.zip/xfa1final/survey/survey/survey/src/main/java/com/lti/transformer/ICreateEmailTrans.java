package com.lti.transformer;

import com.lti.entity.OutcomeFileDetailsEntity;
/**
 * 
 * @author 10667188
 *
 */
public interface ICreateEmailTrans {

	
	void prepareAndSend(OutcomeFileDetailsEntity outcomeFileDetailsEntity);
}
