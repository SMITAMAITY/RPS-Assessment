package com.lti.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.dao.IQuestionDetailsDao;
import com.lti.models.QuestionDetails;


/**
 * 
 * @author 10667187
 *
 */
@Repository
public class QuestionDetailsDaoImpl implements IQuestionDetailsDao {

	private static final Logger LOGGER = LogManager.getLogger(QuestionDetailsDaoImpl.class);
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	public QuestionDetailsDaoImpl() {

	}
	
	@Override
	public List<QuestionDetails> readAllQuestionDetails() {
		
		LOGGER.debug("readAllQuestionDetails Start: ");
		String jpql = "From QuestionDetails";
		TypedQuery<QuestionDetails> tquery = entityManager.createQuery(jpql, QuestionDetails.class);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

	@Override
	public List<QuestionDetails> readQuestionDetailsByFirstCategory() {
		
		LOGGER.debug("readQuestionDetailsByFirstCategory Start: ");
		String jpql = "From CategoryDetails where categoryId = 1";
		Query tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

	@Override
	public List<QuestionDetails> readQuestionDetailsBySecondCategory() {
	
		LOGGER.debug("readQuestionDetailsBySecondCategory Start: ");
		String jpql = "From CategoryDetails where categoryId = 2";
		Query tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
	
	@Override
	public List<QuestionDetails> readQuestionDetailsByThirdCategory() {
		
		LOGGER.debug("readQuestionDetailsByThirdCategory Start: ");
		String jpql = "From CategoryDetails where categoryId = 3";
		Query tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

	@Override
	public List<QuestionDetails> readQuestionDetailsByFourthCategory() {
		
		LOGGER.debug("readQuestionDetailsByFourthCategory Start: ");
		String jpql = "From CategoryDetails where categoryId = 4";
		Query tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}
		
	@Override
	public List<QuestionDetails> readQuestionDetailsByCategoryId(Integer categoryId) {
		
		LOGGER.debug("readQuestionDetailsByFourthCategory Start: ");
		String jpql = "From CategoryDetails where categoryId = " + categoryId;
		Query tquery = entityManager.createQuery(jpql);
		LOGGER.debug(tquery);
		
		return tquery.getResultList();
	}

}