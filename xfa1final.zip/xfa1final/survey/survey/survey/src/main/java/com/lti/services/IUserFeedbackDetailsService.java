package com.lti.services;

import java.util.List;

import com.lti.models.UserFeedbackDetails;

/**
 * 
 * @author 10667188
 *
 */

public interface IUserFeedbackDetailsService {
	
	List<UserFeedbackDetails> findAllUserFeedbackDetails();
	
	void addUserFeedbackDetails(List<UserFeedbackDetails> userFeedbackDetails);
	
	List<UserFeedbackDetails> findByUserId(int id);
	
	List<UserFeedbackDetails> findByUserIdTwo(int id);
	
	List<UserFeedbackDetails> findByUserIdThree(int id);
	
	List<UserFeedbackDetails> findByUserIdFour(int id);
}
