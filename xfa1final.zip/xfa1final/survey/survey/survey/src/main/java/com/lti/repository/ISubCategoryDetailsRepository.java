package com.lti.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.SubCategoryDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface ISubCategoryDetailsRepository extends CrudRepository<SubCategoryDetails, Integer>  {

}
