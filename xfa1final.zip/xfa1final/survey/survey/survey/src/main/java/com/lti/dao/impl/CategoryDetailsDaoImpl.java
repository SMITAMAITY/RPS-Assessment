package com.lti.dao.impl;

import java.util.List;

import com.lti.dao.ICategoryDetailsDao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.models.CategoryDetails;

/**
 * 
 * @author 10667187
 *
 */

@Repository
public class CategoryDetailsDaoImpl implements ICategoryDetailsDao {

private static final Logger LOGGER = LogManager.getLogger(CategoryDetailsDaoImpl.class);
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;

	public CategoryDetailsDaoImpl() {

	}

	@Override
	public List<CategoryDetails> readAllCategoryDetails() {
	
		LOGGER.debug("readAllCategoryDetails Start: ");
		String jpql = "From CategoryDetails";
		TypedQuery<CategoryDetails> tquery = entityManager.createQuery(jpql, CategoryDetails.class);
		LOGGER.debug(tquery);
		return tquery.getResultList();
	}

}
