package com.lti.entity;

import java.io.Serializable;

/**
 * 
 * @author 10667187
 *
 */

public class UserResponseEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int userId;
	
	private String fullName;
	
	private String email;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
