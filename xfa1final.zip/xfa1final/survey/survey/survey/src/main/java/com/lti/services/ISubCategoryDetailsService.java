package com.lti.services;

import java.util.List;

import com.lti.models.SubCategoryDetails;

/**
 * 
 * @author 10667187
 *
 */

public interface ISubCategoryDetailsService {
	
	List<SubCategoryDetails> findAllSubCategoryDetails();
	
	void addSubCategoryDetails(SubCategoryDetails subCategoryDetails);
}
