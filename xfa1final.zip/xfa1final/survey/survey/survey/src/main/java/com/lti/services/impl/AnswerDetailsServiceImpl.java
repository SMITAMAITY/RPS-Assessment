package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.models.AnswerDetails;
import com.lti.repository.IAnswerDetailsRepository;
import com.lti.services.IAnswerDetailsService;
/**
 * 
 * @author 10667187
 *
 */

@Service
public class AnswerDetailsServiceImpl implements IAnswerDetailsService {

	private static final Logger LOGGER = LogManager.getLogger(AnswerDetailsServiceImpl.class);
	
	@Autowired
	private IAnswerDetailsRepository iAnswerDetailsRepository;

	@Override
	public List<AnswerDetails> findAllAnswerDetails() {
		
		LOGGER.debug("findAllAnswerDetails Start: ");
		List<AnswerDetails> users = new ArrayList<>();
		iAnswerDetailsRepository.findAll().forEach(users::add);
		
		return users;
	}

	@Override
	public void addAnswerDetails(AnswerDetails answerDetails) {
		
		LOGGER.debug("addAnswerDetails Start: ");
		iAnswerDetailsRepository.save(answerDetails);
		LOGGER.debug("addAnswerDetails End: ");
	}

}
