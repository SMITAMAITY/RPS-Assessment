package com.lti.dao;

import java.util.List;

import com.lti.models.QuestionDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface IQuestionDetailsDao {
	
	//Select details
	List<QuestionDetails> readAllQuestionDetails();
	
	List<QuestionDetails> readQuestionDetailsByFirstCategory();
	
	List<QuestionDetails> readQuestionDetailsBySecondCategory();
	
	List<QuestionDetails> readQuestionDetailsByThirdCategory();
	
	List<QuestionDetails> readQuestionDetailsByFourthCategory();
	
	List<QuestionDetails> readQuestionDetailsByCategoryId(Integer categoryId);

}