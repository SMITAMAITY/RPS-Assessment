package com.lti.services;

import java.util.List;

import com.lti.entity.UserRegistrationDetailsEntity;
import com.lti.entity.UserResponseEntity;
import com.lti.models.UserRegistrationDetails;

/**
 * 
 * @author 10667187
 *
 */
public interface IUserRegistrationDetailsService {
	
	List<UserRegistrationDetails> findAllUserRegistrationDetails();
	
	void addUserRegistrationDetails(UserRegistrationDetails userRegistrationDetails);
	
	List<UserRegistrationDetails> findLastId();
	
	UserResponseEntity setUserRegistrationDetails(UserRegistrationDetailsEntity userRegistrationDetailsEntity);
	
}
