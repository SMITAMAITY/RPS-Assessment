package com.lti.controllers;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.models.UserFeedbackDetails;
import com.lti.services.impl.UserFeedbackDetailsServiceImpl;

/**
 * 
 * @author 10667187
 *
 */

@RestController
@CrossOrigin
public class UserFeedbackDetailsController {
	
private static final Logger LOGGER = LogManager.getLogger(UserFeedbackDetailsController.class);
	
	@Autowired //how spring will know that it is a dependency
	private UserFeedbackDetailsServiceImpl userFeedbackDetailsServiceImpl;
	
	@RequestMapping(value ="/UserFeedbackDetails", method = RequestMethod.GET)
	public List<UserFeedbackDetails> getUserFeedbackDetails() {
		
		LOGGER.debug("getUserFeedbackDetails Start: ");
		return userFeedbackDetailsServiceImpl.findAllUserFeedbackDetails();
	}
	
	@RequestMapping(value ="/UserFeedbackDetails", method = RequestMethod.POST)
	public void saveUserFeedbackDetails(@RequestBody List<UserFeedbackDetails> userFeedbackDetails) {
		
		LOGGER.debug("saveUserFeedbackDetails Start: ");
		userFeedbackDetailsServiceImpl.addUserFeedbackDetails(userFeedbackDetails);
	}
	
	@RequestMapping(value ="/UserFeedbackDetails/CategoryOne/{id}", method = RequestMethod.GET)
	public List<UserFeedbackDetails> getCategoryOneScores(@PathVariable int id) {
		
		LOGGER.debug("getCategoryOneScores Start: ");
		return userFeedbackDetailsServiceImpl.findByUserId(id);
	}

	@RequestMapping(value ="/UserFeedbackDetails/CategoryTwo/{id}", method = RequestMethod.GET)
	public List<UserFeedbackDetails> getCategoryTwoScores(@PathVariable int id) {
		
		LOGGER.debug("getCategoryTwoScores Start: ");
		return userFeedbackDetailsServiceImpl.findByUserIdTwo(id);
	}

	@RequestMapping(value ="/UserFeedbackDetails/CategoryThree/{id}", method = RequestMethod.GET)
	public List<UserFeedbackDetails> getCategoryThreeScores(@PathVariable int id){
		
		LOGGER.debug("getCategoryThreeScores Start: ");
		return userFeedbackDetailsServiceImpl.findByUserIdThree(id);
	}

	@RequestMapping(value ="/UserFeedbackDetails/CategoryFour/{id}", method = RequestMethod.GET)
	public List<UserFeedbackDetails> getCategoryFourScores(@PathVariable int id) {
		
		LOGGER.debug("getCategoryFourScores Start: ");
		return userFeedbackDetailsServiceImpl.findByUserIdFour(id);
	}
}
