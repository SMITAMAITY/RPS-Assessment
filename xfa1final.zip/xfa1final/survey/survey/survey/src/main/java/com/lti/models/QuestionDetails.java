package com.lti.models;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author 10667187
 *
 */

@Entity
@Table(name="question_details")
public class QuestionDetails {

	@Id
	@Column(name="question_id")
	private int questionId;
	
	@Column(name="question_description")
	private String questionDescription;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_date")
	private Date updatedDate;
	
	@Column(name="is_active")
	private String isActive;
	
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@OneToMany(targetEntity=AnswerDetails.class, cascade=CascadeType.ALL)
	@JoinColumn(name="question_id",referencedColumnName="question_id")
	private List<AnswerDetails> answerDetails;

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getQuestionDescription() {
		return questionDescription;
	}

	public void setQuestionDescription(String questionDescription) {
		this.questionDescription = questionDescription;
	}

	public List<AnswerDetails> getAnswerDetails() {
		return answerDetails;
	}

	public void setAnswerDetails(List<AnswerDetails> answerDetails) {
		this.answerDetails = answerDetails;
	}

	public QuestionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuestionDetails(int questionId, String questionDescription, List<AnswerDetails> answerDetails) {
		super();
		this.questionId = questionId;
		this.questionDescription = questionDescription;
		this.answerDetails = answerDetails;
	}

	@Override
	public String toString() {
		return "QuestionDetails [questionId=" + questionId + ", questionDescription=" + questionDescription
				+ ", answerDetails=" + answerDetails + "]";
	}
	
	
}
