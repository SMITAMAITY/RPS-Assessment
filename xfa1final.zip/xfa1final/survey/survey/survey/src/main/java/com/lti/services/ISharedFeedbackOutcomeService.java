package com.lti.services;

import com.lti.entity.OutcomeFileDetailsEntity;

/**
 * 
 * @author 10667188
 *
 */
public interface ISharedFeedbackOutcomeService {

	void prepareAndSend(OutcomeFileDetailsEntity outcomeFileDetailsEntity);
}
