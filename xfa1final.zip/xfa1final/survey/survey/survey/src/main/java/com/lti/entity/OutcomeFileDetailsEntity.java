package com.lti.entity;

import java.io.Serializable;

import org.springframework.web.multipart.MultipartFile;
/**
 * 
 * @author 10667187
 *
 */

public class OutcomeFileDetailsEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int userId;
	
	private String email;
	
	private String attachmentFilename;
	
	private String fullName;
	
	private MultipartFile outcomeFile;
	
	private MultipartFile blobDetailsIng;
	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAttachmentFilename() {
		return attachmentFilename;
	}

	public void setAttachmentFilename(String attachmentFilename) {
		this.attachmentFilename = attachmentFilename;
	}

	public MultipartFile getOutcomeFile() {
		return outcomeFile;
	}

	public void setOutcomeFile(MultipartFile outcomeFile) {
		this.outcomeFile = outcomeFile;
	}

	public MultipartFile getBlobDetailsIng() {
		return blobDetailsIng;
	}

	public void setBlobDetailsIng(MultipartFile blobDetailsIng) {
		this.blobDetailsIng = blobDetailsIng;
	}

}
