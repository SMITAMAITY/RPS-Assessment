package com.lti.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.IUserFeedbackDetailsDao;

import com.lti.models.UserFeedbackDetails;
import com.lti.repository.IUserFeedbackDetailsRepository;
import com.lti.services.IUserFeedbackDetailsService;
import com.lti.transformer.IUserFeedbackDetailsTrans;

/**
 * 
 * @author 10667188
 *
 */

@Service
public class UserFeedbackDetailsServiceImpl implements IUserFeedbackDetailsService {
	
	private static final Logger LOGGER = LogManager.getLogger(UserFeedbackDetailsServiceImpl.class);

	@Autowired
	private IUserFeedbackDetailsRepository iUserFeedbackDetailsRepository;
	
	@Autowired
	private IUserFeedbackDetailsDao dao;
	
	@Autowired
	private IUserFeedbackDetailsTrans userFeedbackDetailsTrans;
	
	@Override
	public List<UserFeedbackDetails> findAllUserFeedbackDetails() {
		
		LOGGER.debug("findAllUserFeedbackDetails Start: ");
		List<UserFeedbackDetails> users = new ArrayList<>();
		iUserFeedbackDetailsRepository.findAll().forEach(users::add);
		
		return users;
	}

	@Override
	public void addUserFeedbackDetails(List<UserFeedbackDetails> userFeedbackDetails) {

		LOGGER.debug("addUserFeedbackDetails Start: ");
		
		List<UserFeedbackDetails> userFeedbackDetailsUpdate = userFeedbackDetailsTrans.saveUserFeedbackDetails(userFeedbackDetails);
		iUserFeedbackDetailsRepository.saveAll(userFeedbackDetailsUpdate);
		//iUserFeedbackDetailsRepository.saveAll(userFeedbackDetails);
		
		LOGGER.debug("addUserFeedbackDetails End: ");
	}

	@Override
	public List<UserFeedbackDetails> findByUserId(int id) {
		
		LOGGER.debug("findByUserId Start: ");
		return dao.readByUserId(id);
	}

	@Override
	public List<UserFeedbackDetails> findByUserIdTwo(int id) {
		
		LOGGER.debug("findByUserIdTwo Start: ");
		return dao.readByUserIdTwo(id);
	}

	@Override
	public List<UserFeedbackDetails> findByUserIdThree(int id) {
		
		LOGGER.debug("findByUserIdThree Start: ");
		return dao.readByUserIdThree(id);
	}

	@Override
	public List<UserFeedbackDetails> findByUserIdFour(int id) {
		
		LOGGER.debug("findByUserIdFour Start: ");
		return dao.readByUserIdFour(id);
	}
}