import { SurveyService } from './../services/survey.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgForm, NgModel } from '@angular/forms';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-smart-services',
  templateUrl: './smart-services.component.html',
  styleUrls: ['./smart-services.component.css']
})
export class SmartServicesComponent implements OnInit {

  url1:string= "http://localhost:8080/UserFeedbackDetails";
  smartservicesData:any;
  z1:any;
  a:any;
  res:any;
  


constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder, public surveyService :SurveyService) { }

newarray:any =this.surveyService.newarray;

ngOnInit() {

   this.smartservicesData = this.surveyService.getallData();
   console.log(this.smartservicesData);
   

}

submit(){ 
  this.surveyService.sendData();   
    }




ngOnDestroy(): void {
  this.surveyService.setallData(this.smartservicesData);

}
}