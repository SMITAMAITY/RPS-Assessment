import { SurveyService } from './../services/survey.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgForm, NgModel } from '@angular/forms';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit {
  deviceData: any;
  
  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder, public surveyService :SurveyService) { }
  ngOnInit() {
  
    if(this.surveyService.dataFetched){
      console.log("true");
      this.deviceData = this.surveyService.getallData(); 
      console.log(this.deviceData);
    }else{
      console.log("false");

      this.surveyService.fetchData().subscribe(data=>{

       this.deviceData = data;
       console.log(this.deviceData);

        for (let index = 0; index < this.deviceData.length; index++) {

          for(let j=0;j<this.deviceData[index].subCategoryDetails.length;j++){

              for(let k=0;k<this.deviceData[index].subCategoryDetails[j].questionDetails.length;k++){
         
                this.deviceData[index].subCategoryDetails[j].questionDetails[k].selectedAnswer = -1;
                }
                
            }
          
        }
    
    });
    
    }
  
  
  }
  
  continue(){
    this.router.navigate(['secureConnectivity']);
  }
  
  
  ngOnDestroy(): void {
      this.surveyService.setallData(this.deviceData);
      console.log("Device data :"+this.deviceData);
    
  }


}
  
