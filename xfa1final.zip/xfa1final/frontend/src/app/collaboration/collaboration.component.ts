import { SurveyService } from './../services/survey.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgForm, NgModel } from '@angular/forms';
import { NgModule } from '@angular/core';

@Component({
  selector: 'app-collaboration',
  templateUrl: './collaboration.component.html',
  styleUrls: ['./collaboration.component.css']
})
export class CollaborationComponent implements OnInit {

  collaborationData:any;


constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder, public surveyService :SurveyService) { }
ngOnInit() {
  
   this.collaborationData = this.surveyService.getallData();
   console.log(this.collaborationData);
   

}


continue(){
  this.router.navigate(['smartServices']);
}


ngOnDestroy(): void {
  this.surveyService.setallData(this.collaborationData);

}
}

